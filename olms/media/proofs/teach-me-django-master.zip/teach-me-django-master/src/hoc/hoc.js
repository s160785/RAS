const Hoc = props => props.children;

export default Hoc;
